package edu.uajs.listas.ruta;

import java.util.ArrayList;
import java.util.List;

/**
 * PARTE 1 - RutaCircular circular SIN librerías (lista doblemente enlazada circular).
 *
 *            ┌────────────────────────────────────────────┐
 *            ▼                                            │
 *   primero → [A] ⇄ [B] ⇄ [C] ⇄ [D] ⇄ ... ⇄ [Z] ──────────┘
 *              ▲
 *            actual  (la parada que es la parada actual)
 *
 * Dos referencias:
 *   primero: la primera parada agregada. Como la lista es circular,
 *            el ÚLTIMO nodo siempre es  primero.anterior  (¡inserción al final en O(1)!)
 *   actual : la parada que está en servicio ahora
 *
 * Estudiante: busque los comentarios  "TODO"  y complete el código.
 * Después de cada hito ejecute:  mvn test -Dtest=RutaCircularManualTest
 */
public class RutaCircularManual implements RutaCircular {

    private Nodo primero;
    private Nodo actual;
    private int tamanio;

    // ══════════════════════ HITO 1: agregar (≈ 8 min) ══════════════════════
    @Override
    public void agregar(Parada c) {
        Nodo nuevo = new Nodo(c);

        if (primero == null) {
            // Lista vacía: el nodo se apunta a sí mismo en ambos sentidos (YA RESUELTO)
            nuevo.siguiente = nuevo;
            nuevo.anterior = nuevo;
            primero = nuevo;
            actual = nuevo;
        } else {
            Nodo ultimo = primero.anterior;   // el último está "detrás" del primero

            // Los 4 enlaces:  ultimo ⇄ nuevo ⇄ primero
            nuevo.anterior = ultimo;      // el nuevo viene después de 'ultimo'
            nuevo.siguiente = primero;    // después del último viene 'primero'
            ultimo.siguiente = nuevo;     // 'ultimo' avanza hacia el nuevo
            primero.anterior = nuevo;     // 'primero' retrocede hacia el nuevo (cierra el círculo)
        }
        tamanio++;
    }

    @Override
    public Parada actual() {
        return actual == null ? null : actual.dato;   // YA RESUELTO
    }

    // ══════════════════ HITO 2: siguiente / anterior (≈ 6 min) ═════════════
    @Override
    public Parada siguiente() {
        if (actual == null) return null;   // ruta vacía
        // No se pregunta por el último: en una lista circular siguiente nunca es null
        actual = actual.siguiente;
        return actual.dato;
    }

    @Override
    public Parada anterior() {
        if (actual == null) return null;
        actual = actual.anterior;          // incluso desde la primera retrocede a la última
        return actual.dato;
    }

    // ═════════════════ HITO 3: adelantar / retroceder N (≈ 6 min) ══════════
    @Override
    public Parada saltar(int n) {
        if (actual == null) return null;

        n = n % tamanio;                   // las vueltas completas no cambian nada

        for (int i = 0; i < n; i++) {      // n > 0: adelanta
            actual = actual.siguiente;
        }
        for (int i = 0; i > n; i--) {      // n < 0: retrocede
            actual = actual.anterior;
        }
        return actual.dato;
    }

    // ═══════════════ HITO 4: eliminar la que es la parada actual (≈ 10 min) ══════════════
    @Override
    public Parada eliminarActual() {
        if (actual == null) return null;               // YA RESUELTO: vacía

        if (tamanio == 1) {                            // YA RESUELTO: era la única
            primero = null;
            actual = null;
            tamanio = 0;
            return null;
        }

        // Caso general (hay al menos 2 paradas).
        Nodo previo = actual.anterior;                 // YA RESUELTO
        Nodo proximo = actual.siguiente;

        previo.siguiente = proximo;                    // puentear hacia adelante
        proximo.anterior = previo;                     // puentear hacia atrás

        if (actual == primero) {                       // 'primero' no puede quedar apuntando a un nodo eliminado
            primero = proximo;
        }

        actual = proximo;                              // la siguiente pasa a ser la actual
        tamanio--;

        return actual.dato;
    }

    @Override
    public int tamanio() {
        return tamanio;                                // YA RESUELTO
    }

    // ═════════ HITO 5: recorrer una vuelta con do-while (≈ 5 min) ══════════
    @Override
    public int tiempoTotal() {
        if (primero == null) return 0;

        int total = 0;
        Nodo aux = primero;
        do {
            total += aux.dato.minutos();
            aux = aux.siguiente;
        } while (aux != primero);                      
        return total;
    }

    @Override
    public List<String> nombresDesdeActual() {
        // YA RESUELTO: observe el do-while, es el mismo patrón del Hito 5.
        List<String> nombres = new ArrayList<>();
        if (actual == null) return nombres;
        Nodo aux = actual;
        do {
            nombres.add(aux.dato.nombre());
            aux = aux.siguiente;
        } while (aux != actual);
        return nombres;
    }
}